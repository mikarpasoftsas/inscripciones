<?php
// created: 2018-09-18 21:55:03
$dictionary["mks_Courses"]["fields"]["mks_courses_mks_coursesdetail"] = array (
  'name' => 'mks_courses_mks_coursesdetail',
  'type' => 'link',
  'relationship' => 'mks_courses_mks_coursesdetail',
  'source' => 'non-db',
  'module' => 'mks_CoursesDetail',
  'bean_name' => 'mks_CoursesDetail',
  'side' => 'right',
  'vname' => 'LBL_MKS_COURSES_MKS_COURSESDETAIL_FROM_MKS_COURSESDETAIL_TITLE',
);
