<?php
// created: 2018-09-24 16:05:39
$dictionary["mks_Courses"]["fields"]["mks_courses_mks_subjectmatter"] = array (
  'name' => 'mks_courses_mks_subjectmatter',
  'type' => 'link',
  'relationship' => 'mks_courses_mks_subjectmatter',
  'source' => 'non-db',
  'module' => 'mks_SubjectMatter',
  'bean_name' => 'mks_SubjectMatter',
  'side' => 'right',
  'vname' => 'LBL_MKS_COURSES_MKS_SUBJECTMATTER_FROM_MKS_SUBJECTMATTER_TITLE',
);
