<?php
// created: 2018-09-19 21:19:28
$dictionary["Opportunity"]["fields"]["mks_interestcourse_opportunities"] = array (
  'name' => 'mks_interestcourse_opportunities',
  'type' => 'link',
  'relationship' => 'mks_interestcourse_opportunities',
  'source' => 'non-db',
  'module' => 'mks_InterestCourse',
  'bean_name' => 'mks_InterestCourse',
  'side' => 'right',
  'vname' => 'LBL_MKS_INTERESTCOURSE_OPPORTUNITIES_FROM_MKS_INTERESTCOURSE_TITLE',
);
