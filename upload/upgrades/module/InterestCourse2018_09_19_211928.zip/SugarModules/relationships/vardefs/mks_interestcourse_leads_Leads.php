<?php
// created: 2018-09-19 21:02:45
$dictionary["Lead"]["fields"]["mks_interestcourse_leads"] = array (
  'name' => 'mks_interestcourse_leads',
  'type' => 'link',
  'relationship' => 'mks_interestcourse_leads',
  'source' => 'non-db',
  'module' => 'mks_InterestCourse',
  'bean_name' => 'mks_InterestCourse',
  'side' => 'right',
  'vname' => 'LBL_MKS_INTERESTCOURSE_LEADS_FROM_MKS_INTERESTCOURSE_TITLE',
);
