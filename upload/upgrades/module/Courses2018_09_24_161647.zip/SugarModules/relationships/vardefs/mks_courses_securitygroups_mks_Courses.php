<?php
// created: 2018-09-24 16:16:47
$dictionary["mks_Courses"]["fields"]["mks_courses_securitygroups"] = array (
  'name' => 'mks_courses_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_courses_securitygroups',
  'source' => 'non-db',
  'module' => 'SecurityGroups',
  'bean_name' => 'SecurityGroup',
  'vname' => 'LBL_MKS_COURSES_SECURITYGROUPS_FROM_SECURITYGROUPS_TITLE',
);
