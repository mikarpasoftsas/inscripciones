<?php
// created: 2018-09-18 22:05:05
$dictionary["mks_NonworkingDays"]["fields"]["mks_nonworkingdays_securitygroups"] = array (
  'name' => 'mks_nonworkingdays_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_nonworkingdays_securitygroups',
  'source' => 'non-db',
  'module' => 'SecurityGroups',
  'bean_name' => 'SecurityGroup',
  'side' => 'right',
  'vname' => 'LBL_MKS_NONWORKINGDAYS_SECURITYGROUPS_FROM_SECURITYGROUPS_TITLE',
);
