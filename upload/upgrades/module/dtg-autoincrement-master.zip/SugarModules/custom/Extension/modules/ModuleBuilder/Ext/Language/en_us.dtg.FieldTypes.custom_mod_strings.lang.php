<?php

/*
 * The required mod_strings value so the new Autoincrement field is available for us
 */

$mod_strings['fieldTypes']['autoincrement']='Autoincrement';

?>