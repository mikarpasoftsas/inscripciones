<?php
// created: 2018-09-24 16:25:50
$dictionary["mks_Bank"]["fields"]["mks_bank_securitygroups"] = array (
  'name' => 'mks_bank_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_bank_securitygroups',
  'source' => 'non-db',
  'module' => 'SecurityGroups',
  'bean_name' => 'SecurityGroup',
  'vname' => 'LBL_MKS_BANK_SECURITYGROUPS_FROM_SECURITYGROUPS_TITLE',
);
