<?php
// created: 2018-09-24 16:25:50
$dictionary["SecurityGroup"]["fields"]["mks_bank_securitygroups"] = array (
  'name' => 'mks_bank_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_bank_securitygroups',
  'source' => 'non-db',
  'module' => 'mks_Bank',
  'bean_name' => 'mks_Bank',
  'vname' => 'LBL_MKS_BANK_SECURITYGROUPS_FROM_MKS_BANK_TITLE',
);
