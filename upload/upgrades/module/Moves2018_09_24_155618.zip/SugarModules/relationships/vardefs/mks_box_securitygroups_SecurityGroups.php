<?php
// created: 2018-09-24 15:56:18
$dictionary["SecurityGroup"]["fields"]["mks_box_securitygroups"] = array (
  'name' => 'mks_box_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_box_securitygroups',
  'source' => 'non-db',
  'module' => 'mks_Box',
  'bean_name' => 'mks_Box',
  'vname' => 'LBL_MKS_BOX_SECURITYGROUPS_FROM_MKS_BOX_TITLE',
);
