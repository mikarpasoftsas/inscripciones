<?php
// created: 2018-09-24 15:56:18
$dictionary["mks_Movement"]["fields"]["mks_movement_securitygroups"] = array (
  'name' => 'mks_movement_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_movement_securitygroups',
  'source' => 'non-db',
  'module' => 'SecurityGroups',
  'bean_name' => 'SecurityGroup',
  'vname' => 'LBL_MKS_MOVEMENT_SECURITYGROUPS_FROM_SECURITYGROUPS_TITLE',
);
