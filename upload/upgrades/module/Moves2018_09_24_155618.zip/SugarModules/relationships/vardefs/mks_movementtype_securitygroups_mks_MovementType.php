<?php
// created: 2018-09-24 15:56:18
$dictionary["mks_MovementType"]["fields"]["mks_movementtype_securitygroups"] = array (
  'name' => 'mks_movementtype_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_movementtype_securitygroups',
  'source' => 'non-db',
  'module' => 'SecurityGroups',
  'bean_name' => 'SecurityGroup',
  'vname' => 'LBL_MKS_MOVEMENTTYPE_SECURITYGROUPS_FROM_SECURITYGROUPS_TITLE',
);
