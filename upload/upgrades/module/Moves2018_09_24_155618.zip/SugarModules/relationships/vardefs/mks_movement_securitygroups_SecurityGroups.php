<?php
// created: 2018-09-24 15:56:18
$dictionary["SecurityGroup"]["fields"]["mks_movement_securitygroups"] = array (
  'name' => 'mks_movement_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_movement_securitygroups',
  'source' => 'non-db',
  'module' => 'mks_Movement',
  'bean_name' => 'mks_Movement',
  'vname' => 'LBL_MKS_MOVEMENT_SECURITYGROUPS_FROM_MKS_MOVEMENT_TITLE',
);
