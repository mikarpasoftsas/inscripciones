<?php
// created: 2018-09-24 15:56:18
$dictionary["SecurityGroup"]["fields"]["mks_movementtype_securitygroups"] = array (
  'name' => 'mks_movementtype_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_movementtype_securitygroups',
  'source' => 'non-db',
  'module' => 'mks_MovementType',
  'bean_name' => 'mks_MovementType',
  'vname' => 'LBL_MKS_MOVEMENTTYPE_SECURITYGROUPS_FROM_MKS_MOVEMENTTYPE_TITLE',
);
