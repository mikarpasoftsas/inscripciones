<?php
// created: 2018-09-24 17:10:37
$dictionary["Opportunity"]["fields"]["mks_waitinglistassignment_opportunities"] = array (
  'name' => 'mks_waitinglistassignment_opportunities',
  'type' => 'link',
  'relationship' => 'mks_waitinglistassignment_opportunities',
  'source' => 'non-db',
  'module' => 'mks_WaitingListAssignment',
  'bean_name' => 'mks_WaitingListAssignment',
  'side' => 'right',
  'vname' => 'LBL_MKS_WAITINGLISTASSIGNMENT_OPPORTUNITIES_FROM_MKS_WAITINGLISTASSIGNMENT_TITLE',
);
