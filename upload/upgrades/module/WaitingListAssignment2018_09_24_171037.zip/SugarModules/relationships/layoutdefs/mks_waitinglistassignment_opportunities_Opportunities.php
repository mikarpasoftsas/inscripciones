<?php
 // created: 2018-09-24 17:10:37
$layout_defs["Opportunities"]["subpanel_setup"]['mks_waitinglistassignment_opportunities'] = array (
  'order' => 100,
  'module' => 'mks_WaitingListAssignment',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_MKS_WAITINGLISTASSIGNMENT_OPPORTUNITIES_FROM_MKS_WAITINGLISTASSIGNMENT_TITLE',
  'get_subpanel_data' => 'mks_waitinglistassignment_opportunities',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
