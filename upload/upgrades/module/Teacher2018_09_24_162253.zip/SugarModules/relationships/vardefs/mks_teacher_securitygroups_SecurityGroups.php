<?php
// created: 2018-09-24 16:22:53
$dictionary["SecurityGroup"]["fields"]["mks_teacher_securitygroups"] = array (
  'name' => 'mks_teacher_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_teacher_securitygroups',
  'source' => 'non-db',
  'module' => 'mks_Teacher',
  'bean_name' => 'mks_Teacher',
  'vname' => 'LBL_MKS_TEACHER_SECURITYGROUPS_FROM_MKS_TEACHER_TITLE',
);
