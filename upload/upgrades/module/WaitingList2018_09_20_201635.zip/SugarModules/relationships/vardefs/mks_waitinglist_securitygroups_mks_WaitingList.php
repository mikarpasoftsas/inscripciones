<?php
// created: 2018-09-20 20:16:35
$dictionary["mks_WaitingList"]["fields"]["mks_waitinglist_securitygroups"] = array (
  'name' => 'mks_waitinglist_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_waitinglist_securitygroups',
  'source' => 'non-db',
  'module' => 'SecurityGroups',
  'bean_name' => 'SecurityGroup',
  'side' => 'right',
  'vname' => 'LBL_MKS_WAITINGLIST_SECURITYGROUPS_FROM_SECURITYGROUPS_TITLE',
);
