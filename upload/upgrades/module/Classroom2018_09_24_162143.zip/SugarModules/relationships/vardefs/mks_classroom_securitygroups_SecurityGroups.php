<?php
// created: 2018-09-24 16:21:43
$dictionary["SecurityGroup"]["fields"]["mks_classroom_securitygroups"] = array (
  'name' => 'mks_classroom_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_classroom_securitygroups',
  'source' => 'non-db',
  'module' => 'mks_Classroom',
  'bean_name' => 'mks_Classroom',
  'vname' => 'LBL_MKS_CLASSROOM_SECURITYGROUPS_FROM_MKS_CLASSROOM_TITLE',
);
