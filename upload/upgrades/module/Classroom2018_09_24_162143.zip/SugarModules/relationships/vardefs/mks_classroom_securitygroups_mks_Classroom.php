<?php
// created: 2018-09-24 16:21:43
$dictionary["mks_Classroom"]["fields"]["mks_classroom_securitygroups"] = array (
  'name' => 'mks_classroom_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_classroom_securitygroups',
  'source' => 'non-db',
  'module' => 'SecurityGroups',
  'bean_name' => 'SecurityGroup',
  'vname' => 'LBL_MKS_CLASSROOM_SECURITYGROUPS_FROM_SECURITYGROUPS_TITLE',
);
