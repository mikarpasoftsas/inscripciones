<?php
// created: 2018-09-24 16:15:58
$dictionary["SecurityGroup"]["fields"]["mks_courses_securitygroups"] = array (
  'name' => 'mks_courses_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_courses_securitygroups',
  'source' => 'non-db',
  'module' => 'mks_Courses',
  'bean_name' => 'mks_Courses',
  'vname' => 'LBL_MKS_COURSES_SECURITYGROUPS_FROM_MKS_COURSES_TITLE',
);
