<?php
// created: 2018-09-24 16:15:58
$dictionary["SecurityGroup"]["fields"]["mks_subjectmatter_securitygroups"] = array (
  'name' => 'mks_subjectmatter_securitygroups',
  'type' => 'link',
  'relationship' => 'mks_subjectmatter_securitygroups',
  'source' => 'non-db',
  'module' => 'mks_SubjectMatter',
  'bean_name' => 'mks_SubjectMatter',
  'vname' => 'LBL_MKS_SUBJECTMATTER_SECURITYGROUPS_FROM_MKS_SUBJECTMATTER_TITLE',
);
